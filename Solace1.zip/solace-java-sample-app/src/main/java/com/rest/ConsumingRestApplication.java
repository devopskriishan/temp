package com.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

@Configuration
public class ConsumingRestApplication {

	private static final Logger log = LoggerFactory.getLogger(ConsumingRestApplication.class);

	/*
	 * public static void main(String[] args) {
	 * SpringApplication.run(ConsumingRestApplication.class, args); }
	 */

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	/*
	 * @Bean public CommandLineRunner run(RestTemplate restTemplate) throws
	 * Exception { return args -> { Quote quote = restTemplate.getForObject(
	 * "https://gturnquist-quoters.cfapps.io/api/random", Quote.class);
	 * log.info(quote.toString()); }; }
	 */
	
	@Bean
	public CommandLineRunner changeReplicationRole(RestTemplate restTemplate) throws Exception {
		return args -> {
			
			try {
				String jsonInput2 = "{\"replicationRole\":\"standby\"}";
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.setBasicAuth("admin", "admin");
				
				HttpEntity<String> entity = new HttpEntity<String>(jsonInput2, headers);
				String response = restTemplate.patchForObject("http://localhost:8080/SEMP/v2/config/msgVpns/testVPN", entity, java.lang.String.class);
				System.out.println(response);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		
		};
	}
	
	@Bean
	public CommandLineRunner changeDMREnabled(RestTemplate restTemplate) throws Exception {
		return args -> {
			
			try {
				String jsonInput2 = "{\"dmrEnabled\":true}";
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.setBasicAuth("admin", "admin");
				
				HttpEntity<String> entity = new HttpEntity<String>(jsonInput2, headers);
				String response = restTemplate.patchForObject("http://localhost:8080/SEMP/v2/config/msgVpns/testVPN", entity, java.lang.String.class);
				System.out.println(response);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			
		};
	}
	
}
