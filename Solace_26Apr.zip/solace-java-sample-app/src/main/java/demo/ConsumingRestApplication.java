package demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Configuration
public class ConsumingRestApplication {

	private static final Logger log = LoggerFactory.getLogger(ConsumingRestApplication.class);


	 
		public ConsumingRestApplication() {
		
	}


		public void changeDMREnabled() {
		
				try {
					RestTemplate restTemplate = new RestTemplate();

					HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
					requestFactory.setConnectTimeout(1000);
					requestFactory.setReadTimeout(1000);

					restTemplate.setRequestFactory(requestFactory);
					
					String jsonInput2 = "{\"dmrEnabled\":false}";
					HttpHeaders headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_JSON);
					headers.setBasicAuth("admin", "admin");
					
					HttpEntity<String> entity = new HttpEntity<String>(jsonInput2, headers);
					String response = restTemplate.patchForObject("http://localhost:8080/SEMP/v2/config/msgVpns/testVPN", entity, java.lang.String.class);
					//String response = restTemplate.patchForObject("https://mr1dns3dpz5ov5.messaging.solace.cloud:20974/SEMP/v2/config", entity, java.lang.String.class);
					
					System.out.println(response);
				}catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				
		}
	    
	
		public void getRedundancyStatus() {
		
				try {
					RestTemplate restTemplate = new RestTemplate();

					HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
					requestFactory.setConnectTimeout(1000);
					requestFactory.setReadTimeout(1000);

					restTemplate.setRequestFactory(requestFactory);
					String xmlInput = "<rpc semp-version=\"soltr/9_4VMR\"><show><redundancy><detail></detail></redundancy></show></rpc>";

					HttpHeaders headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_XML);
					headers.setBasicAuth("admin", "admin");

					HttpEntity<String> entity = new HttpEntity<String>(xmlInput, headers);

					ResponseEntity<String> reponse = restTemplate.postForEntity("http://localhost:8080/SEMP", entity,
							java.lang.String.class);
					System.out.println(reponse.getBody());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	
}
