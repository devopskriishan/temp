/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package demo;

import java.util.concurrent.CountDownLatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.solacesystems.jcsmp.BytesXMLMessage;
import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.jcsmp.TextMessage;
import com.solacesystems.jcsmp.XMLMessageListener;


public class DemoMessageConsumer implements XMLMessageListener  {
	
	@Autowired
	public ConsumingRestApplication consumingRestApplication;
	

    private CountDownLatch latch = new CountDownLatch(1);
    private static final Logger logger = LoggerFactory.getLogger(DemoMessageConsumer.class);
    
    public void onReceive(BytesXMLMessage msg) {
        if (msg instanceof TextMessage) {
            logger.info("============= TextMessage received: " + ((TextMessage) msg).getText());
        } else {
            logger.info("============= Message received.");
        }
        latch.countDown(); // unblock main thread
    }

    public void onException(JCSMPException e) {
        logger.info("Consumer received exception:  Performing other checks @@@@####%%%%%%----->>>", e);   
         
        getRedundancyStatus();
        
        changeDMREnabled();
        //latch.countDown(); // unblock main thread
       //consumingRestApplication.getRedundancyStatus();
       // consumingRestApplication.changeDMREnabled();
        
    }

	
    public CountDownLatch getLatch() {
        return latch;
    }
    
    @Bean
	public void changeDMREnabled() {
	
			try {
				RestTemplate restTemplate = new RestTemplate();

				HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
				//requestFactory.setConnectTimeout(1000);
				//requestFactory.setReadTimeout(1000);

				restTemplate.setRequestFactory(requestFactory);
				
				String jsonInput2 = "{\"dmrEnabled\":false}";
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.setBasicAuth("admin", "admin");
				
				HttpEntity<String> entity = new HttpEntity<String>(jsonInput2, headers);
				String response = restTemplate.patchForObject("http://localhost:8080/SEMP/v2/config/msgVpns/testVPN", entity, java.lang.String.class);
				//String response = restTemplate.patchForObject("https://mr1dns3dpz5ov5.messaging.solace.cloud:20974/SEMP/v2/config", entity, java.lang.String.class);
				
				System.out.println(response);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			
	}
    
	@Bean
	public void getRedundancyStatus() {
	
			try {
				RestTemplate restTemplate = new RestTemplate();

				HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
				//requestFactory.setConnectTimeout(1000);
				//requestFactory.setReadTimeout(1000);

				restTemplate.setRequestFactory(requestFactory);
				String xmlInput = "<rpc semp-version=\"soltr/9_4VMR\"><show><redundancy><detail></detail></redundancy></show></rpc>";

				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_XML);
				headers.setBasicAuth("admin", "admin");

				HttpEntity<String> entity = new HttpEntity<String>(xmlInput, headers);

				ResponseEntity<String> reponse = restTemplate.postForEntity("http://localhost:8080/SEMP", entity,
						java.lang.String.class);
				System.out.println(reponse.getBody());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


